const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    app: 'Torn Commander Sandbox',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

io.on('connection', (socket) => {
  socket.emit('server:welcome', {
    socketId: socket.id,
    message: 'Connected to the Commander server.'
  });

  socket.on('disconnect', () => {
    // Room cleanup will be added when multiplayer lobbies are introduced.
  });
});

app.use((_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Torn Commander Sandbox running on port ${PORT}`);
});
