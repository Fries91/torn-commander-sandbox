(() => {
  const connectionStatus = document.getElementById('connectionStatus');
  const connectionText = document.getElementById('connectionText');
  const socketCheck = document.getElementById('socketCheck');

  if (typeof io !== 'function') {
    setConnectionState('offline', 'Socket library missing');
    return;
  }

  const socket = io({
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 800
  });

  socket.on('connect', () => {
    setConnectionState('online', 'Server online');
  });

  socket.on('server:welcome', (payload) => {
    console.info(payload.message, payload.socketId);
    socketCheck.textContent = 'Ready';
  });

  socket.on('disconnect', () => {
    setConnectionState('offline', 'Reconnecting…');
    socketCheck.textContent = 'Offline';
  });

  socket.on('connect_error', (error) => {
    console.error('Socket connection error:', error.message);
    setConnectionState('offline', 'Connection failed');
    socketCheck.textContent = 'Error';
  });

  function setConnectionState(state, text) {
    connectionStatus.classList.remove('is-connecting', 'is-online', 'is-offline');
    connectionStatus.classList.add(`is-${state}`);
    connectionText.textContent = text;
  }
})();
