# Torn Commander Sandbox — Step 1

This first stage creates:

- A mobile-friendly Torn-inspired home screen
- A Node.js and Express server
- A working Socket.IO multiplayer connection
- A health-check endpoint at `/api/health`
- A foundation ready for 2–6 player room creation

## Run locally

1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000`.

## Deploy to Render

- Build command: `npm install`
- Start command: `npm start`
- Environment: Node

Render automatically supplies the `PORT` environment variable.

## Next stage

Step 2 will add:

- Create game
- Join by room code
- 2–6 player lobby
- Player names
- Host controls
- Ready status
